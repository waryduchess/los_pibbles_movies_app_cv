// Common Widgets - Componentes básicos reutilizables
export 'common/cr_button.dart';
export 'common/cr_section_header.dart';

// Input Widgets - Campos de formulario e entrada
export 'inputs/cr_text_field.dart';
export 'inputs/cr_search_field.dart';
export 'inputs/cr_radio_card.dart';

// Card Widgets - Componentes tipo tarjeta
export 'cards/movie_review_card.dart';
export 'cards/movie_actor_card.dart';
export 'cards/validation_card_widget.dart';

// Movie Widgets - Componentes específicos de películas
export 'movies/movie_reviews_section.dart';
export 'movies/movie_comments_section.dart';
export 'movies/movie_tech_info.dart';
export 'movies/cr_category_chip.dart';

// Forgot Password Steps - Pasos de recuperación
export 'auth/forgot_password/email_step.dart';
export 'auth/forgot_password/new_password_step.dart';
export 'auth/forgot_password/success_step.dart';

// Settings Widgets - Componentes de configuración
export 'settings/biometric_card_widget.dart';
export 'settings/cr_faq_item.dart';
export 'settings/menu_card_widget.dart';
export 'settings/profile_card_widget.dart';
export 'settings/profile_photo_widget.dart';

// Dialogs - Diálogos
export 'dialogs/logout_dialog.dart';
export 'dialogs/show_logout_dialog.dart';

// Widgets base y utilitarios en la raíz de widgets/
export 'back_button_widget.dart';
export 'biometric_auth_button.dart';
export 'button_widget.dart';
export 'gradient_background_widget.dart';
export 'input_widget.dart';
export 'logout_button_widget.dart';
export 'text_widget.dart';

// Widgets movidos desde presentation/widgets/
export 'add_comment_sheet.dart';
export 'animated_favorite_button.dart';
export 'category_selector.dart';
export 'comment_section.dart';
export 'featured_movie_card.dart';
export 'featured_movie_carousel.dart';
export 'home_comments_section.dart';
export 'movie_card_item.dart';
export 'search_bar_widget.dart';
export 'tag_chip.dart';
export 'tag_chip2.dart';
